@echo off
setlocal
if exist "%~dp0papyrus\dist\Papyrus.exe" (
  start "" "%~dp0papyrus\dist\Papyrus.exe"
  exit /b 0
)
if exist "%~dp0papyrus\target\release\papyrus.exe" (
  start "" "%~dp0papyrus\target\release\papyrus.exe"
  exit /b 0
)
echo Papyrus has not been built yet.
echo Open PowerShell in "%~dp0papyrus" and run: cargo build --release --locked
echo Microsoft Edge WebView2 Evergreen Runtime is required.
pause
exit /b 1
